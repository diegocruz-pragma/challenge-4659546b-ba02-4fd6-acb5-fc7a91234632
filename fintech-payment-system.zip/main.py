import httpx
from fastapi import FastAPI
from pydantic import BaseModel
from src.application.services import PaymentService

app = FastAPI()


class PaymentRequest(BaseModel):
    amount: float
    currency: str


@app.post('/process-payment')
async def process_payment(payment: PaymentRequest):
    service = PaymentService()
    return await service.process(payment)